package com.practice.spring;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class AppMain {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		Employee employee = context.getBean(Employee.class);

		List<String> lst = new ArrayList<String>();
		lst.add("java");
		lst.add("spring");

		employee.setName("");
		employee.setAge(18);
		employee.setEmail("guru@gmail.com");
		employee.setId("ID001");
		employee.setJobDescription("Doing development");
		employee.setMobileNumber("0123456789");
		employee.setRole("Developer");
		employee.setWorking(false);
		employee.setSkills(lst);
		System.out.println(employee);
	}

}
