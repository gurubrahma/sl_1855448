package com.practice.spring;

import java.util.List;

import org.springframework.stereotype.Component;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Component
public class Employee {

	@NotEmpty(message = "name shouldn't be empty")
	private String name;
	@NotBlank(message = "id shouldn't be blank")
	private String id;
	@Email(message = "email is not proper")
	private String email;
	@Size(min = 10, max = 10, message = "length should be 10")
	private String mobileNumber;
	@Min(value = 20, message = "age shouldn't be less than 20")
	@Max(value = 60, message = "age shouldn't be greater than 60")
	private int age;
	@NotNull(message = "role shouldn't empty")
	private String role;
	@Size(min = 10, max = 100, message = "length should be between 10 and 100 characters length")
	private String jobDescription;
	@AssertTrue(message = "working should be true")
	private boolean working;
	@NotEmpty(message = "skils should not be empty")
	private List<@NotNull String> skills;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}

	public boolean isWorking() {
		return working;
	}

	public void setWorking(boolean working) {
		this.working = working;
	}

	public List<String> getSkills() {
		return skills;
	}

	public void setSkills(List<String> skills) {
		this.skills = skills;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", id=" + id + ", email=" + email + ", mobileNumber=" + mobileNumber
				+ ", age=" + age + ", role=" + role + ", jobDescription=" + jobDescription + ", working=" + working
				+ "]";
	}

}
