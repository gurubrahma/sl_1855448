module javaExcercise1 {
}