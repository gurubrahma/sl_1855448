package com.spring.beans;

import org.springframework.stereotype.Component;

//@Component
public class Project {

	private int projectId;
	private String projectDescription;

	public Project(int projectId, String projectDescription) {
		super();
		this.projectId = projectId;
		this.projectDescription = projectDescription;
	}

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getProjectDescription() {
		return projectDescription;
	}

	public void setProjectDescription(String projectDescription) {
		this.projectDescription = projectDescription;
	}

	@Override
	public String toString() {
		return "Project [projectId=" + projectId + ", projectDescription=" + projectDescription + "]";
	}

}
