package com.spring.resource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.spring.beans.Employee;

@Configuration
public class BeanJavaConfiguration {
	
	/*
	 * @Bean public Employee employee() { Employee emp = new Employee();
	 * emp.setId(1234); emp.setName("java"); return emp; }
	 */

}
