package com.spring.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.beans.Employee;
import com.spring.beans.Project;
import com.spring.resource.BeanAnnotationConfiguration;
import com.spring.resource.BeanJavaConfiguration;

public class SpringExample {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/spring/resource/applicationContext.xml");
		
//		ApplicationContext context = new AnnotationConfigApplicationContext(BeanJavaConfiguration.class);
		
//		ApplicationContext context = new AnnotationConfigApplicationContext(BeanAnnotationConfiguration.class);
		
		
		
		  Employee emp = (Employee) context.getBean(Employee.class);
		  System.out.println(emp);
		 
		
			/*
			 * Project pr = (Project) context.getBean("project"); System.out.println(pr);
			 */
		System.out.println("spring example");
	}

}
