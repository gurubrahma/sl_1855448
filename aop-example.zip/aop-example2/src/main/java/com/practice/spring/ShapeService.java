package com.practice.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ShapeService {

	private Circle circle;
	private Triangle triangle;

	public Circle getCircle() {
		return circle;
	}

	@Autowired
	public void setCircle(Circle circle) {
		this.circle = circle;
	}

	public Triangle getTriangle() {
		return triangle;
	}

	@Autowired
	public void setTriangle(Triangle triangle) {
		this.triangle = triangle;
	}

}
