package com.practice.spring;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration
@EnableAspectJAutoProxy
public class AppConfig {

	public Triangle triangle;

	public Circle circle;

	public ShapeService shapeService;

	public LoggingAspect logAspect;

}
