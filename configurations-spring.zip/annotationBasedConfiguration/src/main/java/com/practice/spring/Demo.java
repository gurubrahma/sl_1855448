package com.practice.spring;


import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@Configuration
public class Demo {

	@Bean
	public String setName() {
		return "";
	}
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
		Person person = (Person) context.getBean("person");
		System.out.println(person);
	}

}
